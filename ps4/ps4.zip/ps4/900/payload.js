function GoldHEN212() {
  ShowMSG = "Please wait...Loading GoldHEN 2.1.2!"
  loadmsg();
  PLfile = "GoldHEN212.bin"
  poc();
}
function GoldHEN224() {
  ShowMSG = "Please wait...Loading GoldHEN 2.2.4!"
  loadmsg();
  PLfile = "GoldHEN224.bin"
  poc();
}
function GoldHEN23() {
  ShowMSG = "Please wait...Loading GoldHEN 2.3!"
  loadmsg();
  PLfile = "GoldHEN23.bin"
  poc();
}
function GoldHEN24b5() {
  ShowMSG = "Please wait...Loading GoldHEN 2.4b5!"
  loadmsg();
  PLfile = "GoldHEN24b5.bin"
  poc();
}
function GoldHEN24b18() {
  ShowMSG = "Please wait...Loading GoldHEN 2.4b18!"
  loadmsg();
  PLfile = "GoldHEN24b18.bin"
  poc();
}

// Other Payloads
function app2usb() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "app2usb.bin"
  poc();
}
function appdumper() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "appdumper.bin"
  poc();
}
function dbbackup() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "dbbackup.bin"
  poc();
}
function dbrestore() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "dbrestore.bin"
  poc();
}
function dupdate() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "dupdate.bin"
  poc();
}
function eupdate() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "eupdate.bin"
  poc();
}
function exitidu() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "exitidu.bin"
  poc();
}
function kerneldumper() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "kerneldumper.bin"
  poc();
}
function moduledumper() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "moduledumper.bin"
  poc();
}
function ps4debug() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "ps4debug.bin"
  poc();
}
function webrte() {
  ShowMSG = " انتظر من فضلك...إرسال بايلود! "
  loadmsg();
  PLfile = "webrte.bin"
  poc();
}

//isfayeed