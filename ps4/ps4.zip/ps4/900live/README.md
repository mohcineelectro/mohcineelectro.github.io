# PSFree version 1.5.0

Lapse Kex ported to 9.00 - Still WIP

Very fast and Stable 90%

- Some performance Tweaks add
- Need Add sysveri Patch
  
PR are welcome 

PSFree is a collection of exploits for the PS4 console. The main focus of the 
repo is for the PS4 but we try to make things portable to PS5.

* Exploits
  * PSFree: src/psfree.js
  * Lapse (kernel): src/lapse.js

Donation (Monero/XMR):
86Fk3X9AE94EGKidzRbvyiVgGNYD3qZnuKNq1ZbsomFWXHYm6TtAgz9GNGitPWadkS3Wr9uXoT29U1SfdMtJ7QNKQpW1CVS

# COPYRIGHT AND AUTHORS:
AGPL-3.0-or-later (see src/COPYING). This repo belongs to the group
`anonymous`. We refer to anonymous contributors as "anonymous" as well.

# CREDITS:
- Jhon https://github.com/janisslsm
- SiSTR0 https://github.com/SiSTR0
- CTN https://github.com/ctn123
- Al-Azif https://github.com/al-azif
- abc for PSFree webkit exploit & Lapse kernel Exploit
- Chendochap https://github.com/ChendoChap
- kameleonre.. for porting and chaining psfree + lapse on ps4 9.00 :P
